pathBase='/usr/openkarotz/Extra/'
pathUser =pathBase+'user.txt'

mac = open('/sys/class/net/wlan0/address').readline().replace('\n', '').replace(':','') #automac (pixel :) )
'''
    already=''
    if os.path.exists(pathUser):
        already = open(pathUser).read().replace('\n','') 
'''        

text_file = open(pathUser, "w")
text_file.write(mac)
text_file.close()
